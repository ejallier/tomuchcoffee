<?php

// tout le bas des fichiers HTML

?>


<!-- #FOOTER -->

<footer class="site-footer ">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<h4>Too much Coffee Web Agency</h4>
				
				<p class="clearfix"><img src="../img/logo.png" alt="" width="100px" class="pull-left"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus dolore corporis aliquam nemo nulla porro optio iure saepe eius debitis!</p>
			</div>
			<div class="col-md-6">
				
				<div class="row">
					<div class="col-sm-6">
					<h4>Navigation</h4>
						<ul class="nav nav-pills nav-stacked">
  							<li><a href="#">Contact</a></li>
  							<li><a href="#">Mentions légales</a></li>
						</ul>
					</div>
					<div class="col-sm-6">
					<h4>Social</h4>
						<ul class="nav nav-pills">
 							<li><a href=""><i class="tmc-gplus"></i></a></li>
 							<li><a href=""><i class="tmc-facebook"></i></a></li>
 							<li><a href=""><i class="tmc-twitter"></i></a></li>
 							<li><a href=""><i class="tmc-github-circled"></i></a></li>
				</ul>
					</div>
				</div>
				
			</div>
		</div>
	</div>
</footer>
<!-- #FOOTER -->

</div>
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
</body>
</html>