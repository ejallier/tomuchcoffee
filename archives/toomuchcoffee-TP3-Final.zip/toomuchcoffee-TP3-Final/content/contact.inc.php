<!-- MAIN -->
<main class="container">
	<article class="row">
		<div class="col-md-12">
			<div class="page-header">
				<h2>Contact</h2>
			</div>

			<p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugit, deserunt.</p>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Optio error possimus accusantium debitis voluptas impedit corrupti assumenda eligendi iusto perferendis.</p>
			<p>Sint delectus reiciendis obcaecati aspernatur eos vero, ab itaque voluptates deserunt hic libero quasi dignissimos repellat minima recusandae molestias non.</p>
			<p>Totam quas ullam beatae est. Nemo doloremque consequatur vero consequuntur, quod ducimus fugiat in excepturi ad natus molestiae tempora expedita.</p>
		</div>
	</article>

</main>

<!-- /#MAIN -->
