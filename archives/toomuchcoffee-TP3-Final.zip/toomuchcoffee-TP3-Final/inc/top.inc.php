<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="UTF-8">
	<title>Too Much Coffe</title>
	<link rel="stylesheet" href="style/css/bootstrap.min.css">
	<link rel="stylesheet" href="style/css/social-embedded.css">
	<link rel="stylesheet" href="style/css/perso.css">
</head>
<body>
<div class="wrap ">

<!-- HEADER -->
<header class="site-header container-fluid">

	<div class="row">
		<div class="col-md-12">
			<h1 class="text-center">
				<a href="index.html">
					<img src="img/logo.png" alt="Too much coffee">
				</a>
			</h1>
		</div>
	</div>

</header>
<!-- /#HEADER	-->
