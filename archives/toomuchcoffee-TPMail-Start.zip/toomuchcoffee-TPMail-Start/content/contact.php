<?php
	include("../inc/top.inc.php");
	include("../inc/nav.inc.php");
?>

<!-- MAIN -->
<main class="container">
	<article class="row">
		<div class="col-md-12">
			<div class="page-header">
				<h2>Contact</h2>
			</div>
		</div>
	</article>

</main>

<!-- /MAIN -->

<?php
	include("../inc/bottom.inc.php");
?>
