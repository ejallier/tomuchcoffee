<div class="alert alert-success">
	<strong>Votre message a bien été envoyé !</strong> <br>
	Nous vous re-contacterons dans les plus brefs délais.
</div>
